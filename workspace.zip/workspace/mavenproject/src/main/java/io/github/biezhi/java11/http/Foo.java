package io.github.biezhi.java11.http;

/**
 * @author biezhi
 * @date 2018/7/10
 */
public class Foo {

    String name;
    String url;

}
